No more strength to wait!

user: admin
pass: admin

module #1: homework5/sites/all/modules/geekhub/article_list/
module #2: homework5/sites/all/modules/geekhub/slide_show/